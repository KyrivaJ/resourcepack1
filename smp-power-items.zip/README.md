# SMP Power Items Resource Pack

This pack gives the plugin's custom power items their own item textures.

Use `tools/generate-resourcepack-textures.ps1` to regenerate the PNG files, then zip the contents of this `resourcepack` folder for use as a Minecraft resource pack.
